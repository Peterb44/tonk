package com.androidharness.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.androidharness.app.agent.PermissionMode
import com.androidharness.app.agent.ThinkingLevel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.settingsStore by preferencesDataStore(name = "settings")

private val WEB_SEARCH_PROVIDERS = com.androidharness.app.tools.SearchProviders.ids.toSet()

enum class ThemeMode { SYSTEM, LIGHT, DARK, AMOLED }

@kotlinx.serialization.Serializable
enum class ProgressBarStyle { FLAT, SQUIGGLY }

@kotlinx.serialization.Serializable
data class AppSettings(
    val permissionMode: PermissionMode = PermissionMode.CONFIRM_RISKY,
    val subagentFullAccess: Boolean = false,
    val backgroundSubagents: Boolean = false,
    val subagentCompletionNotifications: Boolean = true,
    val subagentProviderId: String? = null,
    val subagentModel: String? = null,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val colorPalette: ThemePalette = ThemePalette.BLUE,
    val customPalettes: List<CustomThemePalette> = emptyList(),
    /** Settings sections the user built for themselves, shown on the settings home. */
    val customSections: List<CustomSettingsSection> = emptyList(),
    val activeCustomPaletteId: String? = null,
    val harnessCanvas: HarnessCanvasSettings = HarnessCanvasSettings(),
    val harnessGlassEnabled: Boolean = false,
    val harnessLiquidGlass: Boolean = false,
    val harnessGlassTransparency: Float = 0.5f,
    /** Motion blur that follows fast vertical scrolling. Only drawn on Android 12+. */
    val motionBlurEnabled: Boolean = false,
    val motionBlurIntensity: Float = 0.5f,
    val progressBarStyle: ProgressBarStyle = ProgressBarStyle.SQUIGGLY,
    val chatLayout: ChatLayoutStyle = ChatLayoutStyle(),
    val workspaceLayout: WorkspaceLayoutMode = WorkspaceLayoutMode.AUTO,
    val editorWordWrap: Boolean = false,
    val editorMatchCase: Boolean = false,
    val editorRegexSearch: Boolean = false,
    val activeProviderId: String? = null,
    val providerOrder: List<String> = emptyList(),
    val disabledProviderIds: Set<String> = emptySet(),
    val fallbackPolicy: com.androidharness.app.llm.FallbackPolicy = com.androidharness.app.llm.FallbackPolicy(),
    val thinkingLevel: ThinkingLevel = ThinkingLevel.OFF,
    val reasoningConfigs: Map<String, com.androidharness.app.agent.CustomReasoningConfig> = emptyMap(),
    val customThinkingLevels: Map<String, String> = emptyMap(),
    val maxContextTokens: Int = DEFAULT_MAX_CONTEXT,
    /** Default Code auto-compaction threshold; zero keeps the automatic 80% policy. */
    val autoCompactTokens: Int = 0,
    /** Sent when a paused or interrupted task resumes. Blank uses the built-in prompt; a chat can override it. */
    val resumePrompt: String = "",
    val maxOutputTokens: Int = DEFAULT_MAX_OUTPUT,
    /** Tool-call iterations per run. 0 = unlimited. */
    val maxIterations: Int = DEFAULT_MAX_ITERATIONS,
    /** Hold a wakelock while a run is active so runs survive screen-off. */
    val runInBackground: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val keepAlive: Boolean = true,
    /** Promote the agent-run notification to an Android 16 Live Update on this device. */
    val liveUpdatesEnabled: Boolean = true,
    /** Drawer: pinned / archived session ids (DataStore, no DB migration). */
    val pinnedSessions: Set<String> = emptySet(),
    val archivedSessions: Set<String> = emptySet(),
    val sidebarProjects: Boolean = false,
    val pinnedProjects: Set<String> = emptySet(),
    val archivedProjects: Set<String> = emptySet(),
    /** First-run setup was finished or skipped; stops the setup gate. */
    val onboardingDone: Boolean = false,
    /**
     * Model selected from the active provider's catalog. Null = use the
     * provider entry's saved default model.
     */
    val activeModel: String? = null,
    /** On keeps the existing shared picker; off restores each chat's saved models. */
    val sameModelAcrossChats: Boolean = true,
    /** Skill names hidden from the catalog and slash picker. */
    val disabledSkills: Set<String> = emptySet(),
    /**
     * The search provider picked before several could be on at once. Kept for backups and
     * older builds; web_search now uses every provider that is not in [disabledSearchProviders].
     */
    val webSearchProvider: String = "keyless",
    /** Search providers the user switched off. Everything else that is ready (has keys, or needs none) can be used. */
    val disabledSearchProviders: Set<String> = emptySet(),
    /**
     * Screenshots are allowed by default outside credential screens. Off blocks
     * them app wide; screens that show keys and tokens always block.
     */
    val allowScreenshots: Boolean = true,
    /**
     * Separate models per agent mode: plan-mode runs use the planning
     * provider/model, everything else uses the execution one. Off (default)
     * runs everything on the single active model.
     */
    val planningModelsEnabled: Boolean = false,
    val planningProviderId: String? = null,
    val planningModel: String? = null,
    val executionProviderId: String? = null,
    val executionModel: String? = null,
    /** The one-time "you can now use two models" chat dialog was dismissed. */
    val planningModelsPromoSeen: Boolean = false,
    /** The one-time introductory fork dialog was dismissed. */
    val forkPromoSeen: Boolean = false,
    /** Biometric app lock: requires fingerprint/face/PIN authentication to open. */
    val biometricLockEnabled: Boolean = false,
    /** Grace period in minutes before re-locking when app is backgrounded (0 = immediately). */
    val biometricLockTimeoutMinutes: Int = 0,
    /** Voice speech-to-text engine: "inbuilt" (native Android recognizer) or a [VoiceProviderConfig] id. */
    val voiceEngine: String = "inbuilt",
    /** Legacy Groq Whisper model; kept in sync while Groq is the selected provider. */
    val groqWhisperModel: String = "whisper-large-v3",
    /** Text-to-speech engine: "system" (Android TTS) or a [VoiceProviderConfig] id. */
    val ttsEngine: String = TTS_ENGINE_SYSTEM,
    /** Legacy Groq TTS model id; kept in sync while Groq is the selected provider. */
    val ttsGroqModel: String = DEFAULT_TTS_GROQ_MODEL,
    /** Legacy Groq TTS voice id; kept in sync while Groq is the selected provider. */
    val ttsGroqVoice: String = DEFAULT_TTS_GROQ_VOICE,
    /** Per-provider model and voice choices, keyed by provider id. */
    val voiceSelections: Map<String, VoiceSelection> = emptyMap(),
    /** Android TTS voice name; null picks the best voice for the app language. */
    val ttsSystemVoice: String? = null,
    /** Speech rate multiplier shared by both engines. */
    val ttsSpeed: Float = 1f,
    /** Read every finished assistant reply automatically. */
    val ttsAlwaysSpeak: Boolean = false,
    /** The one-time voice configuration promo dialog was dismissed. */
    val voicePromoSeen: Boolean = false,
    /** Auto-send dictation after silence without waiting for the user to press send. */
    val voiceAutoSend: Boolean = false,
    /** Show the Auto Send toggle in the + (composer leading) menu. */
    val voiceAutoSendShowInPlus: Boolean = true,
    /** Silence before auto-sending dictation, in milliseconds (1000..5000, 100ms steps). */
    val voiceAutoSendTimeoutMs: Int = 2000,
    /** The assistant panel over other apps starts listening as soon as it opens. */
    val assistantVoiceFirst: Boolean = false,
    /** How hard the assistant panel thinks; each model maps it to its own levels or ignores it. */
    val assistantThinking: ThinkingLevel = ThinkingLevel.LOW,
    /** The assistant panel reads its answer aloud when the question was spoken. */
    val assistantSpeakReplies: Boolean = true,
    /** The assistant panel's own model; null follows the Chat model. */
    val assistantProviderId: String? = null,
    val assistantModel: String? = null,
    /** Experimental hands-free voice planning. Device-local, never restored from a backup. */
    val liveMode: LiveModeSettings = LiveModeSettings(),
    /** Legacy Code resume toggle kept for old backups; codeStart is authoritative. */
    val resumeLastChat: Boolean = true,
    val startScreen: StartScreen = StartScreen.LAST_SELECTED,
    /** Chat opens a fresh conversation unless the user asks to continue the latest one. */
    val chatStart: ChatStartMode = ChatStartMode.NEW_CHAT,
    val chatKeepThinkingCollapsed: Boolean = true,
    /** Lets Chat set reminders that show as notifications. */
    val chatRemindersEnabled: Boolean = true,
    /** Models that cannot see images get the text read from them on the device instead. */
    val readImageText: Boolean = true,
    val chatSearchCodeChats: Boolean = true,
    val codeSearchChatChats: Boolean = true,
    /** AH Rumble: a haptic pulse whenever a Chat turn moves to a new step. */
    val rumbleEnabled: Boolean = true,
    /** 0..100 percent of the motor's amplitude. */
    val rumbleStrength: Int = RUMBLE_DEFAULT_STRENGTH,
    /** 0 is a crisp tick, 100 is a long soft swell. */
    val rumbleSmoothness: Int = RUMBLE_DEFAULT_SMOOTHNESS,
    val rumbleEngine: RumbleEngine = RumbleEngine.AUTO,
    val rumbleInChat: Boolean = true,
    val rumbleInCode: Boolean = true,
    /** A smooth rumble for as long as a Chat reply streams in; rich visuals get their own. Chat only. */
    val rumbleFlow: Boolean = true,
    /** Pulses closer together than this are dropped so bursts stay calm. */
    val rumbleSpacingMs: Int = RUMBLE_DEFAULT_SPACING_MS,
    val rumbleSkipOnBatterySaver: Boolean = true,
    /** Per-cue overrides keyed by [RumbleCue] name. */
    val rumbleCues: Map<String, RumbleCueConfig> = emptyMap(),
    /** Which hand-tuned set of event patterns applies where no override is saved; picked at random on first run. */
    val rumbleCombo: Int = RUMBLE_DEFAULT_COMBO,
    /** Default image appetite for chats that have not overridden it. */
    val chatImageFrequency: ImageFrequency = ImageFrequency.DEFAULT,
    val chatInstructions: String = "",
    val chatAgents: List<ChatAgentProfile> = emptyList(),
    /** Code opens a fresh conversation unless the user asks to continue the latest one. */
    val codeStart: CodeStartMode = CodeStartMode.LAST_CODE,
    /** Web research effort for Chat turns. */
    val searchDepth: SearchDepth = SearchDepth.AUTO,
    /** What sending a message does while the agent works. */
    val steeringMode: SteeringMode = SteeringMode.AH_AUTO,
    /** Occasional tips about features and settings while the agent works. */
    val runTipsEnabled: Boolean = true,
    /** What the agent may do when asked to change a setting from a conversation. */
    val agentSettingsAccess: AgentSettingsAccess = AgentSettingsAccess.ALLOWED,
    /** Position in the tip rotation, so tips do not repeat until all were shown. */
    val runTipCursor: Int = 0,
    /** Master switch for section memories and legacy project notes. */
    val memoryEnabled: Boolean = true,
    val memoryEntryUnlimited: Boolean = false,
    val memoryEntryMaxChars: Int = MemoryText.DEFAULT_MAX_ENTRY_CHARS,
    val chatMemoryEnabled: Boolean = true,
    val codeMemoryEnabled: Boolean = true,
    val chatRecallCodeMemory: Boolean = false,
    val codeRecallChatMemory: Boolean = false,
    /** Device-local section selection, including an empty Chat or Code draft. */
    val lastConversationKind: ConversationKind = ConversationKind.CODE,
    val showLiveCode: Boolean = true,
    /**
     * A Code question nobody answers continues with its recommended option after five minutes.
     * Off, every question waits for the user, including one already on screen.
     */
    val autoContinueQuestions: Boolean = true,
    /** The task list above the Code composer. The agent keeps writing its list either way. */
    val showTodoList: Boolean = true,
    /** Off removes the task tool and every subagent control, so nothing can start a subagent. */
    val subagentsEnabled: Boolean = true,
    /** Lets the agent show a card with buttons to Android's storage access pages. Never grants anything itself. */
    val storageAccessCards: Boolean = true,
    /** Seconds a stream may stay silent before the run pauses with a stall error. */
    val streamStallTimeoutSeconds: Int = com.androidharness.app.agent.StreamRetrier.DEFAULT_STALL_TIMEOUT_SECONDS,
    /**
     * For models whose server holds a tool call back until it is finished, ask
     * for file contents as streamed reply text so the write shows live.
     */
    val streamFileWritesAsText: Boolean = true,
    /** "providerId|model" keys seen delivering a whole write in one chunk. */
    val bufferedToolCallModels: Set<String> = emptySet(),
    /** Models that called write_file with the file block marker but never wrote the block. */
    val fileBlockDeclinedModels: Set<String> = emptySet(),
    /** "providerId|model" to the input window its server named when it rejected a request as too long. */
    val learnedContextLimits: Map<String, Int> = emptyMap(),
    /** ID of the last active chat session. */
    val lastActiveSessionId: String? = null,
    /** Generate and inject compact codebase symbol index (Repo map) into agent context. */
    val repoMapEnabled: Boolean = true,
    /** Local models start in plain chat until the user enables agent context. */
    val localModelAgentContext: Boolean = false,
    /** Explicit, device-local consent for experimental local model features. */
    val localModelExperimental: Boolean = false,
    /** Provider debug console. Capture is memory-only unless keep-on-device is on. */
    val debugConsoleEnabled: Boolean = false,
    val debugConsoleBodies: Boolean = false,
    val debugConsolePersist: Boolean = false,
    /** Set once the user agreed that bodies may hold prompts and replies. */
    val debugConsoleConsent: Boolean = false,
    val cavemanInstalled: Boolean = false,
    val cavemanIntensity: com.androidharness.app.caveman.CavemanIntensity = com.androidharness.app.caveman.CavemanIntensity.OFF,
    val cavemanWenyan: Boolean = false,
) {
    /** Backwards-compat accessor: timeout in seconds (for old callers / backups). */
    val voiceAutoSendTimeoutSeconds: Int get() = voiceAutoSendTimeoutMs / 1000
    companion object {
        const val DEFAULT_MAX_CONTEXT = 1_000_000
        const val DEFAULT_MAX_OUTPUT = 32_768
        const val DEFAULT_MAX_ITERATIONS = 0 // unlimited
        const val VOICE_ENGINE_INBUILT = "inbuilt"
        const val VOICE_ENGINE_GROQ = "groq"
        const val GROQ_MODEL_WHISPER_V3 = "whisper-large-v3"
        const val GROQ_MODEL_WHISPER_TURBO = "whisper-large-v3-turbo"
        const val TTS_ENGINE_SYSTEM = "system"
        const val TTS_ENGINE_GROQ = "groq"
        const val VOICE_PROVIDER_GROQ = "groq"
        const val DEFAULT_TTS_GROQ_MODEL = "playai-tts"
        const val DEFAULT_TTS_GROQ_VOICE = "Fritz-PlayAI"
    }
}

/**
 * Model and voice the user picked for one voice provider. Stored as a map so
 * adding a provider never needs a new settings field, and a provider that is
 * removed simply leaves an unused entry behind.
 */
@kotlinx.serialization.Serializable
data class VoiceSelection(
    val sttModel: String = "",
    val ttsModel: String = "",
    val ttsVoice: String = "",
)

class SettingsRepository(private val context: Context) {
    suspend fun setFallbackPolicy(policy: com.androidharness.app.llm.FallbackPolicy) {
        val encoded = com.androidharness.app.llm.FallbackPolicy.encode(policy)
        context.settingsStore.edit { it[Keys.FALLBACK_POLICY] = encoded }
    }

    private fun decodeReasoningConfigs(raw: String?): Map<String, com.androidharness.app.agent.CustomReasoningConfig> =
        raw?.let { kotlinx.serialization.json.Json.decodeFromString(it) } ?: emptyMap()

    private fun decodeCustomLevels(raw: String?): Map<String, String> =
        raw?.let { kotlinx.serialization.json.Json.decodeFromString(it) } ?: emptyMap()

    private fun decodeVoiceSelections(raw: String?): Map<String, VoiceSelection> =
        raw?.let {
            runCatching {
                kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
                    .decodeFromString<Map<String, VoiceSelection>>(it)
            }.getOrNull()
        } ?: emptyMap()

    private fun encodeVoiceSelections(selections: Map<String, VoiceSelection>): String =
        kotlinx.serialization.json.Json.encodeToString(selections)

    private fun updateVoiceSelection(
        raw: String?,
        providerId: String,
        transform: (VoiceSelection) -> VoiceSelection,
    ): String {
        val saved = decodeVoiceSelections(raw).toMutableMap()
        saved[providerId] = transform(saved[providerId] ?: VoiceSelection())
        return encodeVoiceSelections(saved)
    }

    suspend fun setReasoningConfig(key: String, config: com.androidharness.app.agent.CustomReasoningConfig?) {
        context.settingsStore.edit { prefs ->
            val saved = decodeReasoningConfigs(prefs[Keys.REASONING_CONFIGS]).toMutableMap()
            if (config == null) saved.remove(key) else saved[key] = config
            prefs[Keys.REASONING_CONFIGS] = kotlinx.serialization.json.Json.encodeToString(saved)
        }
    }

    suspend fun setCustomThinkingLevel(key: String, level: String?) {
        context.settingsStore.edit { prefs ->
            val saved = decodeCustomLevels(prefs[Keys.CUSTOM_THINKING_LEVELS]).toMutableMap()
            if (level == null) saved.remove(key) else saved[key] = level
            prefs[Keys.CUSTOM_THINKING_LEVELS] = kotlinx.serialization.json.Json.encodeToString(saved)
        }
    }

    private object Keys {
        val PERMISSION_MODE = stringPreferencesKey("permission_mode")
        val SUBAGENT_FULL_ACCESS = booleanPreferencesKey("subagent_full_access")
        val BACKGROUND_SUBAGENTS = booleanPreferencesKey("background_subagents")
        val SUBAGENT_COMPLETION_NOTIFICATIONS = booleanPreferencesKey("subagent_completion_notifications")
        val SUBAGENT_PROVIDER = stringPreferencesKey("subagent_provider_id")
        val SUBAGENT_MODEL = stringPreferencesKey("subagent_model")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val DEBUG_CONSOLE_ENABLED = booleanPreferencesKey("debug_console_enabled")
        val DEBUG_CONSOLE_BODIES = booleanPreferencesKey("debug_console_bodies")
        val DEBUG_CONSOLE_PERSIST = booleanPreferencesKey("debug_console_persist")
        val DEBUG_CONSOLE_CONSENT = booleanPreferencesKey("debug_console_consent")
        val COLOR_PALETTE = stringPreferencesKey("color_palette")
        val CUSTOM_PALETTES = stringPreferencesKey("custom_palettes")
        val CUSTOM_SECTIONS = stringPreferencesKey("custom_settings_sections")
        val ACTIVE_CUSTOM_PALETTE = stringPreferencesKey("active_custom_palette")
        val HARNESS_CANVAS = stringPreferencesKey("harness_canvas")
        val HARNESS_GLASS_ENABLED = booleanPreferencesKey("harness_glass_enabled")
        val HARNESS_LIQUID_GLASS = booleanPreferencesKey("harness_liquid_glass")
        val HARNESS_GLASS_TRANSPARENCY = floatPreferencesKey("harness_glass_transparency")
        val MOTION_BLUR_ENABLED = booleanPreferencesKey("motion_blur_enabled")
        val MOTION_BLUR_INTENSITY = floatPreferencesKey("motion_blur_intensity")
        val PROGRESS_BAR_STYLE = stringPreferencesKey("progress_bar_style")
        val CHAT_DENSITY = stringPreferencesKey("chat_density")
        val CHAT_LINE_SPACING = floatPreferencesKey("chat_line_spacing")
        val CHAT_SIDE_MARGIN = intPreferencesKey("chat_side_margin")
        val WORKSPACE_LAYOUT = stringPreferencesKey("workspace_layout")
        val EDITOR_WORD_WRAP = booleanPreferencesKey("editor_word_wrap")
        val EDITOR_MATCH_CASE = booleanPreferencesKey("editor_match_case")
        val EDITOR_REGEX_SEARCH = booleanPreferencesKey("editor_regex_search")
        val ACTIVE_PROVIDER = stringPreferencesKey("active_provider_id")
        val PROVIDER_ORDER = stringPreferencesKey("provider_order")
        val DISABLED_PROVIDERS = stringSetPreferencesKey("disabled_providers")
        val FALLBACK_POLICY = stringPreferencesKey("fallback_policy")
        val THINKING_LEVEL = stringPreferencesKey("thinking_level")
        val REASONING_CONFIGS = stringPreferencesKey("reasoning_configs")
        val CUSTOM_THINKING_LEVELS = stringPreferencesKey("custom_thinking_levels")
        val MAX_CONTEXT = intPreferencesKey("max_context_tokens")
        val AUTO_COMPACT = intPreferencesKey("auto_compact_tokens")
        val RESUME_PROMPT = stringPreferencesKey("resume_prompt")
        val MAX_OUTPUT = intPreferencesKey("max_output_tokens")
        val MAX_ITERATIONS = intPreferencesKey("max_iterations")
        val RUN_IN_BACKGROUND = booleanPreferencesKey("run_in_background")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val KEEP_ALIVE = booleanPreferencesKey("keep_alive")
        val LIVE_UPDATES_ENABLED = booleanPreferencesKey("live_updates_enabled")
        val PINNED = stringSetPreferencesKey("pinned_sessions")
        val ARCHIVED = stringSetPreferencesKey("archived_sessions")
        val SIDEBAR_PROJECTS = booleanPreferencesKey("sidebar_projects")
        val PINNED_PROJECTS = stringSetPreferencesKey("pinned_projects")
        val ARCHIVED_PROJECTS = stringSetPreferencesKey("archived_projects")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val ACTIVE_MODEL = stringPreferencesKey("active_model")
        val SAME_MODEL_ACROSS_CHATS = booleanPreferencesKey("same_model_across_chats")
        val DISABLED_SKILLS = stringSetPreferencesKey("disabled_skills")
        val WEB_SEARCH_PROVIDER = stringPreferencesKey("web_search_provider")
        val DISABLED_SEARCH_PROVIDERS = stringSetPreferencesKey("disabled_search_providers")
        val ALLOW_SCREENSHOTS = booleanPreferencesKey("allow_screenshots")
        val PLANNING_MODELS_ENABLED = booleanPreferencesKey("planning_models_enabled")
        val PLANNING_PROVIDER = stringPreferencesKey("planning_provider_id")
        val PLANNING_MODEL = stringPreferencesKey("planning_model")
        val EXECUTION_PROVIDER = stringPreferencesKey("execution_provider_id")
        val EXECUTION_MODEL = stringPreferencesKey("execution_model")
        val PLANNING_PROMO_SEEN = booleanPreferencesKey("planning_promo_seen")
        val FORK_PROMO_SEEN = booleanPreferencesKey("fork_promo_seen")
        val DONATION_NOTICE_DISMISSED = booleanPreferencesKey("donation_notice_dismissed")
        val BIOMETRIC_LOCK_ENABLED = booleanPreferencesKey("biometric_lock_enabled")
        val BIOMETRIC_LOCK_TIMEOUT = intPreferencesKey("biometric_lock_timeout_minutes")
        val VOICE_ENGINE = stringPreferencesKey("voice_engine")
        val GROQ_WHISPER_MODEL = stringPreferencesKey("groq_whisper_model")
        val TTS_ENGINE = stringPreferencesKey("tts_engine")
        val TTS_GROQ_MODEL = stringPreferencesKey("tts_groq_model")
        val TTS_GROQ_VOICE = stringPreferencesKey("tts_groq_voice")
        val VOICE_SELECTIONS = stringPreferencesKey("voice_provider_selections")
        val TTS_SYSTEM_VOICE = stringPreferencesKey("tts_system_voice")
        val TTS_SPEED = floatPreferencesKey("tts_speed")
        val TTS_ALWAYS_SPEAK = booleanPreferencesKey("tts_always_speak")
        val VOICE_PROMO_SEEN = booleanPreferencesKey("voice_promo_seen")
        val VOICE_AUTO_SEND = booleanPreferencesKey("voice_auto_send")
        val ASSISTANT_VOICE_FIRST = booleanPreferencesKey("assistant_voice_first")
        val ASSISTANT_THINKING = stringPreferencesKey("assistant_thinking")
        val ASSISTANT_SPEAK_REPLIES = booleanPreferencesKey("assistant_speak_replies")
        val ASSISTANT_PROVIDER = stringPreferencesKey("assistant_provider_id")
        val ASSISTANT_MODEL = stringPreferencesKey("assistant_model")
        val VOICE_AUTO_SEND_SHOW_IN_PLUS = booleanPreferencesKey("voice_auto_send_show_in_plus")
        val VOICE_AUTO_SEND_TIMEOUT_SECONDS = intPreferencesKey("voice_auto_send_timeout_seconds")
        val VOICE_AUTO_SEND_TIMEOUT_MS = intPreferencesKey("voice_auto_send_timeout_ms")
        val LIVE_MODE = stringPreferencesKey("live_mode")
        val RESUME_LAST_CHAT = booleanPreferencesKey("resume_last_chat")
        val START_SCREEN = stringPreferencesKey("start_screen")
        val CHAT_KEEP_THINKING_COLLAPSED = booleanPreferencesKey("chat_keep_thinking_collapsed")
        val CHAT_REMINDERS_ENABLED = booleanPreferencesKey("chat_reminders_enabled")
        val READ_IMAGE_TEXT = booleanPreferencesKey("read_image_text")
        val RUMBLE_ENABLED = booleanPreferencesKey("rumble_enabled")
        val RUMBLE_STRENGTH = intPreferencesKey("rumble_strength")
        val RUMBLE_SMOOTHNESS = intPreferencesKey("rumble_smoothness")
        val RUMBLE_ENGINE = stringPreferencesKey("rumble_engine")
        val RUMBLE_IN_CHAT = booleanPreferencesKey("rumble_in_chat")
        val RUMBLE_IN_CODE = booleanPreferencesKey("rumble_in_code")
        val RUMBLE_FLOW = booleanPreferencesKey("rumble_flow")
        val RUMBLE_SPACING = intPreferencesKey("rumble_spacing_ms")
        val RUMBLE_BATTERY_SAVER = booleanPreferencesKey("rumble_skip_on_battery_saver")
        val RUMBLE_CUES = stringPreferencesKey("rumble_cues")
        val RUMBLE_COMBO = intPreferencesKey("rumble_combo")
        val CHAT_IMAGE_FREQUENCY = stringPreferencesKey("chat_image_frequency")
        val CHAT_INSTRUCTIONS = stringPreferencesKey("chat_instructions")
        val CHAT_AGENTS = stringPreferencesKey("chat_agents")
        val CHAT_SEARCH_CODE_CHATS = booleanPreferencesKey("chat_search_code_chats")
        val CODE_SEARCH_CHAT_CHATS = booleanPreferencesKey("code_search_chat_chats")
        val CHAT_START = stringPreferencesKey("chat_start")
        val CODE_START = stringPreferencesKey("code_start")
        val SEARCH_DEPTH = stringPreferencesKey("search_depth")
        val STEERING_MODE = stringPreferencesKey("steering_mode")
        val RUN_TIPS_ENABLED = booleanPreferencesKey("run_tips_enabled")
        val AGENT_SETTINGS_ACCESS = stringPreferencesKey("agent_settings_access")
        val RUN_TIP_CURSOR = intPreferencesKey("run_tip_cursor")
        val CHAT_MEMORY_ENABLED = booleanPreferencesKey("chat_memory_enabled")
        val CODE_MEMORY_ENABLED = booleanPreferencesKey("code_memory_enabled")
        val CHAT_RECALL_CODE_MEMORY = booleanPreferencesKey("chat_recall_code_memory")
        val CODE_RECALL_CHAT_MEMORY = booleanPreferencesKey("code_recall_chat_memory")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val MEMORY_ENTRY_UNLIMITED = booleanPreferencesKey("memory_entry_unlimited")
        val MEMORY_ENTRY_MAX_CHARS = intPreferencesKey("memory_entry_max_chars")
        val LAST_CONVERSATION_KIND = stringPreferencesKey("last_conversation_kind")
        val SHOW_LIVE_CODE = booleanPreferencesKey("show_live_code")
        val AUTO_CONTINUE_QUESTIONS = booleanPreferencesKey("auto_continue_questions")
        val SHOW_TODO_LIST = booleanPreferencesKey("show_todo_list")
        val SUBAGENTS_ENABLED = booleanPreferencesKey("subagents_enabled")
        val STORAGE_ACCESS_CARDS = booleanPreferencesKey("storage_access_cards")
        val STREAM_STALL_TIMEOUT_SECONDS = intPreferencesKey("stream_stall_timeout_seconds")
        val STREAM_FILE_WRITES_AS_TEXT = booleanPreferencesKey("stream_file_writes_as_text")
        val BUFFERED_TOOL_CALL_MODELS = stringSetPreferencesKey("buffered_tool_call_models")
        val FILE_BLOCK_DECLINED_MODELS = stringSetPreferencesKey("file_block_declined_models")
        val LEARNED_CONTEXT_LIMITS = stringSetPreferencesKey("learned_context_limits")
        val LAST_ACTIVE_SESSION = stringPreferencesKey("last_active_session_id")
        val REPO_MAP_ENABLED = booleanPreferencesKey("repo_map_enabled")
        val LOCAL_MODEL_AGENT_CONTEXT = booleanPreferencesKey("local_model_agent_context")
        val LOCAL_MODEL_EXPERIMENTAL = booleanPreferencesKey("local_model_experimental")
        val CAVEMAN_INSTALLED = booleanPreferencesKey("caveman_installed")
        val CAVEMAN_INTENSITY = stringPreferencesKey("caveman_intensity")
        val CAVEMAN_WENYAN = booleanPreferencesKey("caveman_wenyan")
    }

    /** Device-local dismissal shared by the empty Chat and Code screens. */
    val donationNoticeDismissed: Flow<Boolean> = context.settingsStore.data.map { prefs ->
        prefs[Keys.DONATION_NOTICE_DISMISSED] ?: false
    }

    suspend fun setDonationNoticeDismissed(dismissed: Boolean) {
        context.settingsStore.edit { it[Keys.DONATION_NOTICE_DISMISSED] = dismissed }
    }

    val settings: Flow<AppSettings> = context.settingsStore.data.map { prefs ->
        AppSettings(
            permissionMode = prefs[Keys.PERMISSION_MODE]
                ?.let { runCatching { PermissionMode.valueOf(it) }.getOrNull() }
                ?: PermissionMode.CONFIRM_RISKY,
            subagentFullAccess = prefs[Keys.SUBAGENT_FULL_ACCESS] ?: false,
            backgroundSubagents = prefs[Keys.BACKGROUND_SUBAGENTS] ?: false,
            subagentCompletionNotifications = prefs[Keys.SUBAGENT_COMPLETION_NOTIFICATIONS] ?: true,
            themeMode = prefs[Keys.THEME_MODE]
                ?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            dynamicColor = prefs[Keys.DYNAMIC_COLOR] ?: true,
            colorPalette = ThemePalette.fromStored(prefs[Keys.COLOR_PALETTE]),
            customPalettes = runCatching { kotlinx.serialization.json.Json.decodeFromString<List<CustomThemePalette>>(prefs[Keys.CUSTOM_PALETTES] ?: "[]") }.getOrDefault(emptyList()),
            customSections = CustomSettingsSections.decode(prefs[Keys.CUSTOM_SECTIONS]),
            activeCustomPaletteId = prefs[Keys.ACTIVE_CUSTOM_PALETTE],
            harnessCanvas = runCatching { kotlinx.serialization.json.Json.decodeFromString<HarnessCanvasSettings>(prefs[Keys.HARNESS_CANVAS] ?: "{}") }.getOrDefault(HarnessCanvasSettings()),
            harnessGlassEnabled = prefs[Keys.HARNESS_GLASS_ENABLED] ?: false,
            harnessLiquidGlass = prefs[Keys.HARNESS_LIQUID_GLASS] ?: false,
            harnessGlassTransparency = (prefs[Keys.HARNESS_GLASS_TRANSPARENCY] ?: .5f).let { if (it.isFinite()) it.coerceIn(0f, 1f) else .5f },
            motionBlurEnabled = prefs[Keys.MOTION_BLUR_ENABLED] ?: false,
            motionBlurIntensity = (prefs[Keys.MOTION_BLUR_INTENSITY] ?: .5f).let { if (it.isFinite()) it.coerceIn(0f, 1f) else .5f },
            progressBarStyle = ProgressBarStyle.entries.firstOrNull { it.name == prefs[Keys.PROGRESS_BAR_STYLE] }
                ?: ProgressBarStyle.SQUIGGLY,
            chatLayout = ChatLayoutStyle(
                density = ChatDensity.entries.firstOrNull { it.name == prefs[Keys.CHAT_DENSITY] } ?: ChatDensity.DEFAULT,
                lineSpacing = ChatLayoutStyle.clampLineSpacing(prefs[Keys.CHAT_LINE_SPACING]),
                sideMargin = ChatLayoutStyle.clampSideMargin(prefs[Keys.CHAT_SIDE_MARGIN]),
            ),
            workspaceLayout = WorkspaceLayoutMode.fromStored(prefs[Keys.WORKSPACE_LAYOUT])
                ?: WorkspaceLayoutMode.AUTO,
            editorWordWrap = prefs[Keys.EDITOR_WORD_WRAP] ?: false,
            editorMatchCase = prefs[Keys.EDITOR_MATCH_CASE] ?: false,
            editorRegexSearch = prefs[Keys.EDITOR_REGEX_SEARCH] ?: false,
            activeProviderId = prefs[Keys.ACTIVE_PROVIDER] ?: com.androidharness.app.llm.HarnessProvider.ID,
            providerOrder = ProviderListPreferences.decodeOrder(prefs[Keys.PROVIDER_ORDER]),
            disabledProviderIds = prefs[Keys.DISABLED_PROVIDERS] ?: emptySet(),
            fallbackPolicy = com.androidharness.app.llm.FallbackPolicy.decode(prefs[Keys.FALLBACK_POLICY]),
            thinkingLevel = prefs[Keys.THINKING_LEVEL]
                ?.let { runCatching { ThinkingLevel.valueOf(it) }.getOrNull() }
                ?: ThinkingLevel.OFF,
            reasoningConfigs = decodeReasoningConfigs(prefs[Keys.REASONING_CONFIGS]),
            customThinkingLevels = decodeCustomLevels(prefs[Keys.CUSTOM_THINKING_LEVELS]),
            maxContextTokens = prefs[Keys.MAX_CONTEXT] ?: AppSettings.DEFAULT_MAX_CONTEXT,
            autoCompactTokens = prefs[Keys.AUTO_COMPACT] ?: 0,
            resumePrompt = prefs[Keys.RESUME_PROMPT].orEmpty(),
            maxOutputTokens = prefs[Keys.MAX_OUTPUT] ?: AppSettings.DEFAULT_MAX_OUTPUT,
            maxIterations = prefs[Keys.MAX_ITERATIONS] ?: AppSettings.DEFAULT_MAX_ITERATIONS,
            runInBackground = prefs[Keys.RUN_IN_BACKGROUND] ?: true,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            keepAlive = prefs[Keys.KEEP_ALIVE] ?: true,
            liveUpdatesEnabled = prefs[Keys.LIVE_UPDATES_ENABLED] ?: true,
            pinnedSessions = prefs[Keys.PINNED] ?: emptySet(),
            archivedSessions = prefs[Keys.ARCHIVED] ?: emptySet(),
            sidebarProjects = prefs[Keys.SIDEBAR_PROJECTS] ?: false,
            pinnedProjects = prefs[Keys.PINNED_PROJECTS] ?: emptySet(),
            archivedProjects = prefs[Keys.ARCHIVED_PROJECTS] ?: emptySet(),
            onboardingDone = prefs[Keys.ONBOARDING_DONE] ?: false,
            activeModel = prefs[Keys.ACTIVE_MODEL],
            sameModelAcrossChats = prefs[Keys.SAME_MODEL_ACROSS_CHATS] ?: true,
            disabledSkills = prefs[Keys.DISABLED_SKILLS] ?: emptySet(),
            webSearchProvider = prefs[Keys.WEB_SEARCH_PROVIDER]
                ?.takeIf { it in WEB_SEARCH_PROVIDERS }
                ?: "keyless",
            disabledSearchProviders = prefs[Keys.DISABLED_SEARCH_PROVIDERS].orEmpty().filterTo(HashSet()) { it in WEB_SEARCH_PROVIDERS },
            allowScreenshots = prefs[Keys.ALLOW_SCREENSHOTS] ?: true,
            planningModelsEnabled = prefs[Keys.PLANNING_MODELS_ENABLED] ?: false,
            planningProviderId = prefs[Keys.PLANNING_PROVIDER],
            planningModel = prefs[Keys.PLANNING_MODEL],
            executionProviderId = prefs[Keys.EXECUTION_PROVIDER],
            executionModel = prefs[Keys.EXECUTION_MODEL],
            subagentProviderId = prefs[Keys.SUBAGENT_PROVIDER],
            subagentModel = prefs[Keys.SUBAGENT_MODEL],
            planningModelsPromoSeen = prefs[Keys.PLANNING_PROMO_SEEN] ?: false,
            forkPromoSeen = prefs[Keys.FORK_PROMO_SEEN] ?: false,
            biometricLockEnabled = prefs[Keys.BIOMETRIC_LOCK_ENABLED] ?: false,
            biometricLockTimeoutMinutes = prefs[Keys.BIOMETRIC_LOCK_TIMEOUT] ?: 0,
            voiceEngine = prefs[Keys.VOICE_ENGINE] ?: AppSettings.VOICE_ENGINE_INBUILT,
            groqWhisperModel = prefs[Keys.GROQ_WHISPER_MODEL] ?: AppSettings.GROQ_MODEL_WHISPER_V3,
            ttsEngine = prefs[Keys.TTS_ENGINE] ?: AppSettings.TTS_ENGINE_SYSTEM,
            ttsGroqModel = prefs[Keys.TTS_GROQ_MODEL] ?: AppSettings.DEFAULT_TTS_GROQ_MODEL,
            ttsGroqVoice = prefs[Keys.TTS_GROQ_VOICE] ?: AppSettings.DEFAULT_TTS_GROQ_VOICE,
            voiceSelections = decodeVoiceSelections(prefs[Keys.VOICE_SELECTIONS]),
            ttsSystemVoice = prefs[Keys.TTS_SYSTEM_VOICE]?.ifBlank { null },
            ttsSpeed = prefs[Keys.TTS_SPEED] ?: 1f,
            ttsAlwaysSpeak = prefs[Keys.TTS_ALWAYS_SPEAK] ?: false,
            voicePromoSeen = prefs[Keys.VOICE_PROMO_SEEN] ?: false,
            voiceAutoSend = prefs[Keys.VOICE_AUTO_SEND] ?: false,
            assistantVoiceFirst = prefs[Keys.ASSISTANT_VOICE_FIRST] ?: false,
            assistantThinking = prefs[Keys.ASSISTANT_THINKING]
                ?.let { runCatching { ThinkingLevel.valueOf(it) }.getOrNull() }
                ?: ThinkingLevel.LOW,
            assistantSpeakReplies = prefs[Keys.ASSISTANT_SPEAK_REPLIES] ?: true,
            assistantProviderId = prefs[Keys.ASSISTANT_PROVIDER],
            assistantModel = prefs[Keys.ASSISTANT_MODEL],
            voiceAutoSendShowInPlus = prefs[Keys.VOICE_AUTO_SEND_SHOW_IN_PLUS] ?: true,
            voiceAutoSendTimeoutMs = (prefs[Keys.VOICE_AUTO_SEND_TIMEOUT_MS] ?: prefs[Keys.VOICE_AUTO_SEND_TIMEOUT_SECONDS]?.let { it * 1000 } ?: 2000).coerceIn(1000, 5000),
            liveMode = liveModeFrom(prefs[Keys.LIVE_MODE]),
            resumeLastChat = prefs[Keys.RESUME_LAST_CHAT] ?: true,
            startScreen = StartScreen.fromStored(prefs[Keys.START_SCREEN]),
            chatStart = ChatStartMode.fromStored(prefs[Keys.CHAT_START]),
            chatSearchCodeChats = prefs[Keys.CHAT_SEARCH_CODE_CHATS] ?: true,
            codeSearchChatChats = prefs[Keys.CODE_SEARCH_CHAT_CHATS] ?: true,
            chatKeepThinkingCollapsed = prefs[Keys.CHAT_KEEP_THINKING_COLLAPSED] ?: true,
            chatRemindersEnabled = prefs[Keys.CHAT_REMINDERS_ENABLED] ?: true,
            readImageText = prefs[Keys.READ_IMAGE_TEXT] ?: true,
            rumbleEnabled = prefs[Keys.RUMBLE_ENABLED] ?: true,
            rumbleStrength = (prefs[Keys.RUMBLE_STRENGTH] ?: RUMBLE_DEFAULT_STRENGTH).coerceIn(0, 100),
            rumbleSmoothness = (prefs[Keys.RUMBLE_SMOOTHNESS] ?: RUMBLE_DEFAULT_SMOOTHNESS).coerceIn(0, 100),
            rumbleEngine = prefs[Keys.RUMBLE_ENGINE]?.let { runCatching { RumbleEngine.valueOf(it) }.getOrNull() } ?: RumbleEngine.AUTO,
            rumbleInChat = prefs[Keys.RUMBLE_IN_CHAT] ?: true,
            rumbleInCode = prefs[Keys.RUMBLE_IN_CODE] ?: true,
            rumbleFlow = prefs[Keys.RUMBLE_FLOW] ?: true,
            rumbleSpacingMs = (prefs[Keys.RUMBLE_SPACING] ?: RUMBLE_DEFAULT_SPACING_MS).coerceIn(RUMBLE_MIN_SPACING_MS, RUMBLE_MAX_SPACING_MS),
            rumbleSkipOnBatterySaver = prefs[Keys.RUMBLE_BATTERY_SAVER] ?: true,
            rumbleCues = decodeRumbleCues(prefs[Keys.RUMBLE_CUES]),
            rumbleCombo = (prefs[Keys.RUMBLE_COMBO] ?: RUMBLE_DEFAULT_COMBO).coerceIn(0, RUMBLE_COMBO_COUNT - 1),
            chatInstructions = prefs[Keys.CHAT_INSTRUCTIONS].orEmpty(),
            chatAgents = ChatAgentProfile.decodeList(prefs[Keys.CHAT_AGENTS]),
            chatImageFrequency = prefs[Keys.CHAT_IMAGE_FREQUENCY]?.let {
                runCatching { ImageFrequency.valueOf(it) }.getOrNull()
            } ?: ImageFrequency.DEFAULT,
            codeStart = prefs[Keys.CODE_START]?.let { CodeStartMode.fromStored(it) }
                ?: if (prefs[Keys.RESUME_LAST_CHAT] ?: true) CodeStartMode.LAST_CODE else CodeStartMode.NEW_CODE,
            searchDepth = SearchDepth.fromStored(prefs[Keys.SEARCH_DEPTH]),
            steeringMode = SteeringMode.fromStored(prefs[Keys.STEERING_MODE]),
            runTipsEnabled = prefs[Keys.RUN_TIPS_ENABLED] ?: true,
            agentSettingsAccess = AgentSettingsAccess.fromStored(prefs[Keys.AGENT_SETTINGS_ACCESS]),
            runTipCursor = prefs[Keys.RUN_TIP_CURSOR] ?: 0,
            chatMemoryEnabled = prefs[Keys.CHAT_MEMORY_ENABLED] ?: true,
            codeMemoryEnabled = prefs[Keys.CODE_MEMORY_ENABLED] ?: true,
            chatRecallCodeMemory = prefs[Keys.CHAT_RECALL_CODE_MEMORY] ?: false,
            codeRecallChatMemory = prefs[Keys.CODE_RECALL_CHAT_MEMORY] ?: false,
            memoryEnabled = prefs[Keys.MEMORY_ENABLED] ?: true,
            memoryEntryUnlimited = prefs[Keys.MEMORY_ENTRY_UNLIMITED] ?: false,
            memoryEntryMaxChars = prefs[Keys.MEMORY_ENTRY_MAX_CHARS]?.takeIf { it > 0 } ?: MemoryText.DEFAULT_MAX_ENTRY_CHARS,
            lastConversationKind = ConversationKind.entries.firstOrNull { it.name == prefs[Keys.LAST_CONVERSATION_KIND] } ?: ConversationKind.CODE,
            showLiveCode = prefs[Keys.SHOW_LIVE_CODE] ?: true,
            autoContinueQuestions = prefs[Keys.AUTO_CONTINUE_QUESTIONS] ?: true,
            showTodoList = prefs[Keys.SHOW_TODO_LIST] ?: true,
            subagentsEnabled = prefs[Keys.SUBAGENTS_ENABLED] ?: true,
            storageAccessCards = prefs[Keys.STORAGE_ACCESS_CARDS] ?: true,
            streamStallTimeoutSeconds = prefs[Keys.STREAM_STALL_TIMEOUT_SECONDS]
                ?: com.androidharness.app.agent.StreamRetrier.DEFAULT_STALL_TIMEOUT_SECONDS,
            streamFileWritesAsText = prefs[Keys.STREAM_FILE_WRITES_AS_TEXT] ?: true,
            bufferedToolCallModels = prefs[Keys.BUFFERED_TOOL_CALL_MODELS] ?: emptySet(),
            fileBlockDeclinedModels = prefs[Keys.FILE_BLOCK_DECLINED_MODELS] ?: emptySet(),
            learnedContextLimits = decodeContextLimits(prefs[Keys.LEARNED_CONTEXT_LIMITS]),
            lastActiveSessionId = prefs[Keys.LAST_ACTIVE_SESSION],
            repoMapEnabled = prefs[Keys.REPO_MAP_ENABLED] ?: true,
            localModelAgentContext = prefs[Keys.LOCAL_MODEL_AGENT_CONTEXT] ?: false,
            localModelExperimental = prefs[Keys.LOCAL_MODEL_EXPERIMENTAL] ?: false,
            cavemanInstalled = prefs[Keys.CAVEMAN_INSTALLED] ?: false,
            cavemanIntensity = prefs[Keys.CAVEMAN_INTENSITY]?.let {
                runCatching { com.androidharness.app.caveman.CavemanIntensity.valueOf(it) }.getOrNull()
            } ?: com.androidharness.app.caveman.CavemanIntensity.OFF,
            cavemanWenyan = prefs[Keys.CAVEMAN_WENYAN] ?: false,
            debugConsoleEnabled = prefs[Keys.DEBUG_CONSOLE_ENABLED] ?: false,
            debugConsoleBodies = prefs[Keys.DEBUG_CONSOLE_BODIES] ?: false,
            debugConsolePersist = prefs[Keys.DEBUG_CONSOLE_PERSIST] ?: false,
            debugConsoleConsent = prefs[Keys.DEBUG_CONSOLE_CONSENT] ?: false,
        )
    }

    suspend fun restorePortable(s: AppSettings) {
        context.settingsStore.edit { p ->
            p[Keys.THEME_MODE] = s.themeMode.name
            p[Keys.DYNAMIC_COLOR] = s.dynamicColor
            p[Keys.COLOR_PALETTE] = s.colorPalette.name
            p[Keys.CUSTOM_PALETTES] = kotlinx.serialization.json.Json.encodeToString(s.customPalettes)
            p[Keys.CUSTOM_SECTIONS] = CustomSettingsSections.encode(s.customSections)
            s.activeCustomPaletteId?.let { p[Keys.ACTIVE_CUSTOM_PALETTE] = it } ?: p.remove(Keys.ACTIVE_CUSTOM_PALETTE)
            p[Keys.HARNESS_CANVAS] = kotlinx.serialization.json.Json.encodeToString(s.harnessCanvas)
            p[Keys.HARNESS_GLASS_ENABLED] = s.harnessGlassEnabled
            p[Keys.HARNESS_LIQUID_GLASS] = s.harnessLiquidGlass
            p[Keys.HARNESS_GLASS_TRANSPARENCY] = s.harnessGlassTransparency.let { if (it.isFinite()) it.coerceIn(0f, 1f) else .5f }
            p[Keys.MOTION_BLUR_ENABLED] = s.motionBlurEnabled
            p[Keys.MOTION_BLUR_INTENSITY] = s.motionBlurIntensity.let { if (it.isFinite()) it.coerceIn(0f, 1f) else .5f }
            p[Keys.PROGRESS_BAR_STYLE] = s.progressBarStyle.name
            p[Keys.CHAT_DENSITY] = s.chatLayout.density.name
            p[Keys.CHAT_LINE_SPACING] = ChatLayoutStyle.clampLineSpacing(s.chatLayout.lineSpacing)
            p[Keys.CHAT_SIDE_MARGIN] = ChatLayoutStyle.clampSideMargin(s.chatLayout.sideMargin)
            p[Keys.WORKSPACE_LAYOUT] = s.workspaceLayout.name
            p[Keys.EDITOR_WORD_WRAP] = s.editorWordWrap
            p[Keys.EDITOR_MATCH_CASE] = s.editorMatchCase
            p[Keys.EDITOR_REGEX_SEARCH] = s.editorRegexSearch
            p[Keys.PROVIDER_ORDER] = ProviderListPreferences.encodeOrder(s.providerOrder)
            p[Keys.DISABLED_PROVIDERS] = s.disabledProviderIds
            p[Keys.FALLBACK_POLICY] = com.androidharness.app.llm.FallbackPolicy.encode(s.fallbackPolicy)
            p[Keys.THINKING_LEVEL] = s.thinkingLevel.name
            p[Keys.REASONING_CONFIGS] = kotlinx.serialization.json.Json.encodeToString(s.reasoningConfigs)
            p[Keys.CUSTOM_THINKING_LEVELS] = kotlinx.serialization.json.Json.encodeToString(s.customThinkingLevels)
            p[Keys.MAX_CONTEXT] = s.maxContextTokens
            p[Keys.AUTO_COMPACT] = s.autoCompactTokens
            p[Keys.RESUME_PROMPT] = s.resumePrompt
            p[Keys.MAX_OUTPUT] = s.maxOutputTokens
            p[Keys.MAX_ITERATIONS] = s.maxIterations
            p[Keys.RUN_IN_BACKGROUND] = s.runInBackground
            p[Keys.NOTIFICATIONS_ENABLED] = s.notificationsEnabled
            p[Keys.KEEP_ALIVE] = s.keepAlive
            p[Keys.LIVE_UPDATES_ENABLED] = s.liveUpdatesEnabled
            p[Keys.SUBAGENT_FULL_ACCESS] = s.subagentFullAccess
            p[Keys.BACKGROUND_SUBAGENTS] = s.backgroundSubagents
            p[Keys.SUBAGENT_COMPLETION_NOTIFICATIONS] = s.subagentCompletionNotifications
            p[Keys.DISABLED_SKILLS] = s.disabledSkills
            p[Keys.WEB_SEARCH_PROVIDER] = s.webSearchProvider
            p[Keys.DISABLED_SEARCH_PROVIDERS] = s.disabledSearchProviders.filterTo(HashSet()) { it in WEB_SEARCH_PROVIDERS }
            p[Keys.VOICE_ENGINE] = s.voiceEngine
            p[Keys.GROQ_WHISPER_MODEL] = s.groqWhisperModel
            p[Keys.TTS_ENGINE] = s.ttsEngine
            p[Keys.TTS_GROQ_MODEL] = s.ttsGroqModel
            p[Keys.TTS_GROQ_VOICE] = s.ttsGroqVoice
            p[Keys.VOICE_SELECTIONS] = encodeVoiceSelections(s.voiceSelections)
            p[Keys.TTS_SYSTEM_VOICE] = s.ttsSystemVoice.orEmpty()
            p[Keys.TTS_SPEED] = s.ttsSpeed
            p[Keys.TTS_ALWAYS_SPEAK] = s.ttsAlwaysSpeak
            p[Keys.VOICE_AUTO_SEND] = s.voiceAutoSend
            p[Keys.ASSISTANT_VOICE_FIRST] = s.assistantVoiceFirst
            p[Keys.ASSISTANT_THINKING] = s.assistantThinking.name
            p[Keys.ASSISTANT_SPEAK_REPLIES] = s.assistantSpeakReplies
            p[Keys.VOICE_AUTO_SEND_SHOW_IN_PLUS] = s.voiceAutoSendShowInPlus
            p[Keys.VOICE_AUTO_SEND_TIMEOUT_MS] = s.voiceAutoSendTimeoutMs.coerceIn(1000, 5000)
            p[Keys.VOICE_AUTO_SEND_TIMEOUT_SECONDS] = s.voiceAutoSendTimeoutMs.coerceIn(1000, 5000) / 1000
            p[Keys.RESUME_LAST_CHAT] = s.resumeLastChat
            p[Keys.START_SCREEN] = s.startScreen.name
            p[Keys.CHAT_START] = s.chatStart.name
            p[Keys.CHAT_SEARCH_CODE_CHATS] = s.chatSearchCodeChats
            p[Keys.CODE_SEARCH_CHAT_CHATS] = s.codeSearchChatChats
            p[Keys.CHAT_KEEP_THINKING_COLLAPSED] = s.chatKeepThinkingCollapsed
            p[Keys.CHAT_REMINDERS_ENABLED] = s.chatRemindersEnabled
            p[Keys.READ_IMAGE_TEXT] = s.readImageText
            p[Keys.RUMBLE_ENABLED] = s.rumbleEnabled
            p[Keys.RUMBLE_STRENGTH] = s.rumbleStrength.coerceIn(0, 100)
            p[Keys.RUMBLE_SMOOTHNESS] = s.rumbleSmoothness.coerceIn(0, 100)
            p[Keys.RUMBLE_ENGINE] = s.rumbleEngine.name
            p[Keys.RUMBLE_IN_CHAT] = s.rumbleInChat
            p[Keys.RUMBLE_IN_CODE] = s.rumbleInCode
            p[Keys.RUMBLE_FLOW] = s.rumbleFlow
            p[Keys.RUMBLE_SPACING] = s.rumbleSpacingMs.coerceIn(RUMBLE_MIN_SPACING_MS, RUMBLE_MAX_SPACING_MS)
            p[Keys.RUMBLE_BATTERY_SAVER] = s.rumbleSkipOnBatterySaver
            p[Keys.RUMBLE_CUES] = encodeRumbleCues(s.rumbleCues)
            p[Keys.RUMBLE_COMBO] = s.rumbleCombo.coerceIn(0, RUMBLE_COMBO_COUNT - 1)
            p[Keys.CHAT_IMAGE_FREQUENCY] = s.chatImageFrequency.name
            p[Keys.CHAT_INSTRUCTIONS] = s.chatInstructions.take(ConversationConfig.MAX_INSTRUCTIONS_CHARS)
            p[Keys.CHAT_AGENTS] = ChatAgentProfile.encodeList(s.chatAgents)
            p[Keys.CODE_START] = s.codeStart.name
            p[Keys.SEARCH_DEPTH] = s.searchDepth.name
            p[Keys.STEERING_MODE] = s.steeringMode.name
            p[Keys.RUN_TIPS_ENABLED] = s.runTipsEnabled
            p[Keys.AGENT_SETTINGS_ACCESS] = s.agentSettingsAccess.name
            p[Keys.CHAT_MEMORY_ENABLED] = s.chatMemoryEnabled
            p[Keys.CODE_MEMORY_ENABLED] = s.codeMemoryEnabled
            p[Keys.CHAT_RECALL_CODE_MEMORY] = s.chatRecallCodeMemory
            p[Keys.CODE_RECALL_CHAT_MEMORY] = s.codeRecallChatMemory
            p[Keys.MEMORY_ENABLED] = s.memoryEnabled
            p[Keys.MEMORY_ENTRY_UNLIMITED] = s.memoryEntryUnlimited
            p[Keys.MEMORY_ENTRY_MAX_CHARS] = s.memoryEntryMaxChars.takeIf { it > 0 } ?: MemoryText.DEFAULT_MAX_ENTRY_CHARS
            p[Keys.SHOW_LIVE_CODE] = s.showLiveCode
            p[Keys.AUTO_CONTINUE_QUESTIONS] = s.autoContinueQuestions
            p[Keys.SHOW_TODO_LIST] = s.showTodoList
            p[Keys.SUBAGENTS_ENABLED] = s.subagentsEnabled
            p[Keys.STORAGE_ACCESS_CARDS] = s.storageAccessCards
            p[Keys.STREAM_STALL_TIMEOUT_SECONDS] = s.streamStallTimeoutSeconds
            p[Keys.STREAM_FILE_WRITES_AS_TEXT] = s.streamFileWritesAsText
            p[Keys.BUFFERED_TOOL_CALL_MODELS] = s.bufferedToolCallModels
            p[Keys.FILE_BLOCK_DECLINED_MODELS] = s.fileBlockDeclinedModels
            p[Keys.LEARNED_CONTEXT_LIMITS] = encodeContextLimits(s.learnedContextLimits)
            p[Keys.REPO_MAP_ENABLED] = s.repoMapEnabled
            p[Keys.LOCAL_MODEL_AGENT_CONTEXT] = s.localModelAgentContext
            p[Keys.LOCAL_MODEL_EXPERIMENTAL] = s.localModelExperimental
            p[Keys.CAVEMAN_INSTALLED] = s.cavemanInstalled
            p[Keys.CAVEMAN_INTENSITY] = s.cavemanIntensity.name
            p[Keys.CAVEMAN_WENYAN] = s.cavemanWenyan
            p[Keys.PLANNING_MODELS_ENABLED] = s.planningModelsEnabled
            p[Keys.SAME_MODEL_ACROSS_CHATS] = s.sameModelAcrossChats
            listOf(Keys.ACTIVE_PROVIDER to s.activeProviderId, Keys.ACTIVE_MODEL to s.activeModel,
                Keys.PLANNING_PROVIDER to s.planningProviderId, Keys.PLANNING_MODEL to s.planningModel,
                Keys.EXECUTION_PROVIDER to s.executionProviderId, Keys.EXECUTION_MODEL to s.executionModel,
                Keys.SUBAGENT_PROVIDER to s.subagentProviderId, Keys.SUBAGENT_MODEL to s.subagentModel,
                Keys.ASSISTANT_PROVIDER to s.assistantProviderId, Keys.ASSISTANT_MODEL to s.assistantModel
            ).forEach { (key, value) -> if (value == null) p.remove(key) else p[key] = value }
        }
    }

    suspend fun setWebSearchProvider(provider: String) {
        if (provider !in WEB_SEARCH_PROVIDERS) return
        context.settingsStore.edit { it[Keys.WEB_SEARCH_PROVIDER] = provider }
    }

    /** Turns one search provider on or off for web_search. */
    suspend fun setSearchProviderEnabled(provider: String, enabled: Boolean) {
        if (provider !in WEB_SEARCH_PROVIDERS) return
        context.settingsStore.edit { prefs ->
            val disabled = prefs[Keys.DISABLED_SEARCH_PROVIDERS].orEmpty()
            prefs[Keys.DISABLED_SEARCH_PROVIDERS] = if (enabled) disabled - provider else disabled + provider
        }
    }

    suspend fun setProviderEnabled(id: String, enabled: Boolean) {
        context.settingsStore.edit { prefs ->
            val disabled = prefs[Keys.DISABLED_PROVIDERS].orEmpty()
            prefs[Keys.DISABLED_PROVIDERS] = if (enabled) disabled - id else disabled + id
        }
    }

    suspend fun moveProvider(id: String, direction: Int, availableIds: List<String>, visibleIds: List<String>) {
        context.settingsStore.edit { prefs ->
            val order = ProviderListPreferences.move(
                ProviderListPreferences.decodeOrder(prefs[Keys.PROVIDER_ORDER]), availableIds, visibleIds, id, direction,
            )
            prefs[Keys.PROVIDER_ORDER] = ProviderListPreferences.encodeOrder(order)
        }
    }

    suspend fun setDebugConsole(enabled: Boolean, bodies: Boolean, persist: Boolean) {
        context.settingsStore.edit {
            it[Keys.DEBUG_CONSOLE_ENABLED] = enabled
            it[Keys.DEBUG_CONSOLE_BODIES] = bodies && enabled
            it[Keys.DEBUG_CONSOLE_PERSIST] = persist && enabled
        }
    }

    suspend fun setDebugConsent() {
        context.settingsStore.edit { it[Keys.DEBUG_CONSOLE_CONSENT] = true }
    }

    suspend fun setPermissionMode(mode: PermissionMode) {
        context.settingsStore.edit { it[Keys.PERMISSION_MODE] = mode.name }
    }

    suspend fun setSubagentFullAccess(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.SUBAGENT_FULL_ACCESS] = enabled }
    }

    suspend fun setStorageAccessCards(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.STORAGE_ACCESS_CARDS] = enabled }
    }

    suspend fun setStreamStallTimeoutSeconds(seconds: Int) {
        context.settingsStore.edit {
            it[Keys.STREAM_STALL_TIMEOUT_SECONDS] =
                if (seconds == com.androidharness.app.agent.StreamRetrier.STALL_TIMEOUT_NEVER) seconds
                else seconds.coerceIn(
                    com.androidharness.app.agent.StreamRetrier.MIN_STALL_TIMEOUT_SECONDS,
                    com.androidharness.app.agent.StreamRetrier.MAX_STALL_TIMEOUT_SECONDS)
        }
    }

    suspend fun setStreamFileWritesAsText(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.STREAM_FILE_WRITES_AS_TEXT] = enabled }
    }

    /** Remembers a model whose server delivered a whole file write in one chunk. */
    suspend fun markBufferedToolCalls(key: String) {
        context.settingsStore.edit { it[Keys.BUFFERED_TOOL_CALL_MODELS] = it[Keys.BUFFERED_TOOL_CALL_MODELS].orEmpty() + key }
    }

    /** Remembers a model that would not write file blocks, so it goes back to plain write_file calls. */
    /** Remembers the input window a server named when it rejected a request from this model as too long. */
    suspend fun learnContextLimit(key: String, tokens: Int) {
        context.settingsStore.edit {
            it[Keys.LEARNED_CONTEXT_LIMITS] = encodeContextLimits(
                decodeContextLimits(it[Keys.LEARNED_CONTEXT_LIMITS]) + (key to tokens))
        }
    }

    suspend fun markFileBlocksDeclined(key: String) {
        context.settingsStore.edit { it[Keys.FILE_BLOCK_DECLINED_MODELS] = it[Keys.FILE_BLOCK_DECLINED_MODELS].orEmpty() + key }
    }

    suspend fun setSubagentsEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.SUBAGENTS_ENABLED] = enabled }
    }

    suspend fun setAutoContinueQuestions(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.AUTO_CONTINUE_QUESTIONS] = enabled }
    }

    suspend fun setShowTodoList(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.SHOW_TODO_LIST] = enabled }
    }

    suspend fun setBackgroundSubagents(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.BACKGROUND_SUBAGENTS] = enabled }
    }

    suspend fun setSubagentCompletionNotifications(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.SUBAGENT_COMPLETION_NOTIFICATIONS] = enabled }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.settingsStore.edit {
            it[Keys.DYNAMIC_COLOR] = enabled
            if (enabled) {
                val canvas = canvasFrom(it[Keys.HARNESS_CANVAS])
                it[Keys.HARNESS_CANVAS] = kotlinx.serialization.json.Json.encodeToString(canvas.copy(adaptColors = false))
            }
        }
    }

    suspend fun setColorPalette(palette: ThemePalette) {
        context.settingsStore.edit {
            it[Keys.COLOR_PALETTE] = palette.name
            it[Keys.DYNAMIC_COLOR] = false
            it.remove(Keys.ACTIVE_CUSTOM_PALETTE)
            it[Keys.HARNESS_CANVAS] = kotlinx.serialization.json.Json.encodeToString(canvasFrom(it[Keys.HARNESS_CANVAS]).copy(adaptColors = false))
        }
    }

    private fun canvasFrom(raw: String?) = runCatching {
        kotlinx.serialization.json.Json.decodeFromString<HarnessCanvasSettings>(raw ?: "{}")
    }.getOrDefault(HarnessCanvasSettings())

    /** Applies [transform] to the saved custom sections; a result that breaks the limits is dropped. */
    suspend fun updateCustomSections(transform: (List<CustomSettingsSection>) -> List<CustomSettingsSection>) {
        context.settingsStore.edit { prefs ->
            val next = transform(CustomSettingsSections.decode(prefs[Keys.CUSTOM_SECTIONS]))
            if (CustomSettingsSections.valid(next)) prefs[Keys.CUSTOM_SECTIONS] = CustomSettingsSections.encode(next)
        }
    }

    /** Replaces all custom sections at once, as the agent's changes and their Undo do. Throws when [sections] break the limits. */
    suspend fun setCustomSections(sections: List<CustomSettingsSection>) {
        require(CustomSettingsSections.valid(sections)) { "Those sections break the limits." }
        context.settingsStore.edit { prefs -> prefs[Keys.CUSTOM_SECTIONS] = CustomSettingsSections.encode(sections) }
    }

    suspend fun saveCustomPalette(palette: CustomThemePalette) {
        require(palette.valid())
        context.settingsStore.edit { prefs ->
            val existing = runCatching { kotlinx.serialization.json.Json.decodeFromString<List<CustomThemePalette>>(prefs[Keys.CUSTOM_PALETTES] ?: "[]") }.getOrDefault(emptyList())
            require(existing.size < 24 || existing.any { it.id == palette.id })
            val saved = palette.copy(name = palette.name.trim())
            prefs[Keys.CUSTOM_PALETTES] = kotlinx.serialization.json.Json.encodeToString(existing.filterNot { it.id == saved.id } + saved)
            prefs[Keys.ACTIVE_CUSTOM_PALETTE] = saved.id
            prefs[Keys.DYNAMIC_COLOR] = false
            prefs[Keys.HARNESS_CANVAS] = kotlinx.serialization.json.Json.encodeToString(canvasFrom(prefs[Keys.HARNESS_CANVAS]).copy(adaptColors = false))
        }
    }

    suspend fun selectCustomPalette(id: String) {
        context.settingsStore.edit { prefs ->
            val saved = runCatching { kotlinx.serialization.json.Json.decodeFromString<List<CustomThemePalette>>(prefs[Keys.CUSTOM_PALETTES] ?: "[]") }.getOrDefault(emptyList())
            require(saved.any { it.id == id })
            prefs[Keys.ACTIVE_CUSTOM_PALETTE] = id
            prefs[Keys.DYNAMIC_COLOR] = false
            prefs[Keys.HARNESS_CANVAS] = kotlinx.serialization.json.Json.encodeToString(canvasFrom(prefs[Keys.HARNESS_CANVAS]).copy(adaptColors = false))
        }
    }

    suspend fun removeCustomPalette(id: String) {
        context.settingsStore.edit { prefs ->
            val saved = runCatching { kotlinx.serialization.json.Json.decodeFromString<List<CustomThemePalette>>(prefs[Keys.CUSTOM_PALETTES] ?: "[]") }.getOrDefault(emptyList())
            prefs[Keys.CUSTOM_PALETTES] = kotlinx.serialization.json.Json.encodeToString(saved.filterNot { it.id == id })
            if (prefs[Keys.ACTIVE_CUSTOM_PALETTE] == id) prefs.remove(Keys.ACTIVE_CUSTOM_PALETTE)
        }
    }

    suspend fun setHarnessGlassEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.HARNESS_GLASS_ENABLED] = enabled }
    }

    suspend fun setHarnessLiquidGlass(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.HARNESS_LIQUID_GLASS] = enabled }
    }

    suspend fun setHarnessGlassTransparency(value: Float) {
        if (!value.isFinite()) return
        context.settingsStore.edit { it[Keys.HARNESS_GLASS_TRANSPARENCY] = value.coerceIn(0f, 1f) }
    }

    suspend fun setMotionBlurEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.MOTION_BLUR_ENABLED] = enabled }
    }

    suspend fun setMotionBlurIntensity(value: Float) {
        if (!value.isFinite()) return
        context.settingsStore.edit { it[Keys.MOTION_BLUR_INTENSITY] = value.coerceIn(0f, 1f) }
    }

    suspend fun updateHarnessCanvas(transform: (HarnessCanvasSettings) -> HarnessCanvasSettings) {
        context.settingsStore.edit { prefs ->
            val canvas = transform(canvasFrom(prefs[Keys.HARNESS_CANVAS])).let {
                it.copy(dim = if (it.dim.isFinite()) it.dim.coerceIn(0f, 1f) else .65f)
            }
            prefs[Keys.HARNESS_CANVAS] = kotlinx.serialization.json.Json.encodeToString(canvas)
            if (canvas.adaptColors) {
                prefs[Keys.DYNAMIC_COLOR] = false
            }
        }
    }

    suspend fun setChatLayout(style: ChatLayoutStyle) {
        context.settingsStore.edit {
            it[Keys.CHAT_DENSITY] = style.density.name
            it[Keys.CHAT_LINE_SPACING] = ChatLayoutStyle.clampLineSpacing(style.lineSpacing)
            it[Keys.CHAT_SIDE_MARGIN] = ChatLayoutStyle.clampSideMargin(style.sideMargin)
        }
    }

    suspend fun setProgressBarStyle(style: ProgressBarStyle) {
        context.settingsStore.edit { it[Keys.PROGRESS_BAR_STYLE] = style.name }
    }

    suspend fun setWorkspaceLayout(mode: WorkspaceLayoutMode) {
        context.settingsStore.edit { it[Keys.WORKSPACE_LAYOUT] = mode.name }
    }

    suspend fun setEditorWordWrap(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.EDITOR_WORD_WRAP] = enabled }
    }

    suspend fun setEditorSearchOptions(matchCase: Boolean? = null, regex: Boolean? = null) {
        context.settingsStore.edit {
            if (matchCase != null) it[Keys.EDITOR_MATCH_CASE] = matchCase
            if (regex != null) it[Keys.EDITOR_REGEX_SEARCH] = regex
        }
    }

    suspend fun setAllowScreenshots(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.ALLOW_SCREENSHOTS] = enabled }
    }

    suspend fun setPlanningModelsEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.PLANNING_MODELS_ENABLED] = enabled }
    }

    suspend fun setPlanningModelsPromoSeen(seen: Boolean) {
        context.settingsStore.edit { it[Keys.PLANNING_PROMO_SEEN] = seen }
    }

    suspend fun setForkPromoSeen(seen: Boolean) {
        context.settingsStore.edit { it[Keys.FORK_PROMO_SEEN] = seen }
    }

    suspend fun setBiometricLockEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.BIOMETRIC_LOCK_ENABLED] = enabled }
    }

    suspend fun setBiometricLockTimeout(minutes: Int) {
        context.settingsStore.edit { it[Keys.BIOMETRIC_LOCK_TIMEOUT] = minutes }
    }

    suspend fun setVoiceEngine(engine: String) {
        context.settingsStore.edit { it[Keys.VOICE_ENGINE] = engine }
    }

    suspend fun setGroqWhisperModel(model: String) {
        context.settingsStore.edit {
            it[Keys.GROQ_WHISPER_MODEL] = model
            it[Keys.VOICE_SELECTIONS] = updateVoiceSelection(it[Keys.VOICE_SELECTIONS], AppSettings.VOICE_PROVIDER_GROQ) { sel ->
                sel.copy(sttModel = model)
            }
        }
    }

    /** Remembers the model/voice the user picked for one provider. */
    suspend fun setVoiceSelection(providerId: String, transform: (VoiceSelection) -> VoiceSelection) {
        context.settingsStore.edit { prefs ->
            prefs[Keys.VOICE_SELECTIONS] = updateVoiceSelection(prefs[Keys.VOICE_SELECTIONS], providerId, transform)
        }
    }

    suspend fun setVoiceProviderSttModel(providerId: String, model: String) =
        setVoiceSelection(providerId) { it.copy(sttModel = model) }

    suspend fun setVoiceProviderTtsModel(providerId: String, model: String) =
        setVoiceSelection(providerId) { it.copy(ttsModel = model) }

    suspend fun setVoiceProviderTtsVoice(providerId: String, voice: String) =
        setVoiceSelection(providerId) { it.copy(ttsVoice = voice) }

    suspend fun setTtsEngine(engine: String) {
        context.settingsStore.edit { it[Keys.TTS_ENGINE] = engine }
    }

    suspend fun setTtsGroqModel(model: String) {
        context.settingsStore.edit { it[Keys.TTS_GROQ_MODEL] = model }
    }

    suspend fun setTtsGroqVoice(voice: String) {
        context.settingsStore.edit { it[Keys.TTS_GROQ_VOICE] = voice }
    }

    suspend fun setTtsSystemVoice(voice: String?) {
        context.settingsStore.edit { it[Keys.TTS_SYSTEM_VOICE] = voice.orEmpty() }
    }

    suspend fun setTtsSpeed(speed: Float) {
        context.settingsStore.edit { it[Keys.TTS_SPEED] = speed.coerceIn(0.5f, 2f) }
    }

    suspend fun setTtsAlwaysSpeak(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.TTS_ALWAYS_SPEAK] = enabled }
    }

    suspend fun setVoiceAutoSend(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.VOICE_AUTO_SEND] = enabled }
    }

    suspend fun setAssistantVoiceFirst(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.ASSISTANT_VOICE_FIRST] = enabled }
    }

    suspend fun setAssistantThinking(level: ThinkingLevel) {
        context.settingsStore.edit { it[Keys.ASSISTANT_THINKING] = level.name }
    }

    suspend fun setAssistantSpeakReplies(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.ASSISTANT_SPEAK_REPLIES] = enabled }
    }

    suspend fun setVoiceAutoSendShowInPlus(visible: Boolean) {
        context.settingsStore.edit { it[Keys.VOICE_AUTO_SEND_SHOW_IN_PLUS] = visible }
    }

    suspend fun setVoiceAutoSendTimeoutMs(ms: Int) {
        val clamped = ms.coerceIn(1000, 5000)
        context.settingsStore.edit {
            it[Keys.VOICE_AUTO_SEND_TIMEOUT_MS] = clamped
            it[Keys.VOICE_AUTO_SEND_TIMEOUT_SECONDS] = clamped / 1000
        }
    }

    // Backwards-compat overload taking seconds (old callers / backups).
    suspend fun setVoiceAutoSendTimeoutSeconds(seconds: Int) {
        setVoiceAutoSendTimeoutMs(seconds.coerceIn(1, 5) * 1000)
    }

    private fun liveModeFrom(raw: String?): LiveModeSettings =
        raw?.let { runCatching { kotlinx.serialization.json.Json { ignoreUnknownKeys = true }.decodeFromString<LiveModeSettings>(it) }.getOrNull() }
            ?: LiveModeSettings()

    suspend fun updateLiveMode(transform: (LiveModeSettings) -> LiveModeSettings) {
        context.settingsStore.edit { prefs ->
            val next = transform(liveModeFrom(prefs[Keys.LIVE_MODE])).let {
                it.copy(silenceMs = it.silenceMs.coerceIn(LiveModeSettings.MIN_SILENCE_MS, LiveModeSettings.MAX_SILENCE_MS))
            }
            prefs[Keys.LIVE_MODE] = kotlinx.serialization.json.Json.encodeToString(LiveModeSettings.serializer(), next)
        }
    }

    suspend fun setVoicePromoSeen(seen: Boolean) {
        context.settingsStore.edit { it[Keys.VOICE_PROMO_SEEN] = seen }
    }

    suspend fun setPlanningModel(providerId: String?, model: String?) {
        context.settingsStore.edit { prefs ->
            if (providerId == null) prefs.remove(Keys.PLANNING_PROVIDER)
            else prefs[Keys.PLANNING_PROVIDER] = providerId
            if (model.isNullOrBlank()) prefs.remove(Keys.PLANNING_MODEL)
            else prefs[Keys.PLANNING_MODEL] = model
        }
    }

    suspend fun setExecutionModel(providerId: String?, model: String?) {
        context.settingsStore.edit { prefs ->
            if (providerId == null) prefs.remove(Keys.EXECUTION_PROVIDER)
            else prefs[Keys.EXECUTION_PROVIDER] = providerId
            if (model.isNullOrBlank()) prefs.remove(Keys.EXECUTION_MODEL)
            else prefs[Keys.EXECUTION_MODEL] = model
        }
    }

    /** The assistant panel's model; a null provider goes back to following Chat. */
    suspend fun setAssistantModel(providerId: String?, model: String?) {
        context.settingsStore.edit { prefs ->
            if (providerId.isNullOrBlank()) {
                prefs.remove(Keys.ASSISTANT_PROVIDER)
                prefs.remove(Keys.ASSISTANT_MODEL)
            } else {
                prefs[Keys.ASSISTANT_PROVIDER] = providerId
                if (model.isNullOrBlank()) prefs.remove(Keys.ASSISTANT_MODEL)
                else prefs[Keys.ASSISTANT_MODEL] = model
            }
        }
    }

    suspend fun setSubagentModel(providerId: String?, model: String?) {
        context.settingsStore.edit { prefs ->
            if (providerId.isNullOrBlank()) {
                prefs.remove(Keys.SUBAGENT_PROVIDER)
                prefs.remove(Keys.SUBAGENT_MODEL)
            } else {
                prefs[Keys.SUBAGENT_PROVIDER] = providerId
                if (model.isNullOrBlank()) prefs.remove(Keys.SUBAGENT_MODEL)
                else prefs[Keys.SUBAGENT_MODEL] = model
            }
        }
    }

    suspend fun setActiveProvider(id: String?) {
        context.settingsStore.edit { prefs ->
            if (id == null) prefs.remove(Keys.ACTIVE_PROVIDER)
            else prefs[Keys.ACTIVE_PROVIDER] = id
        }
    }

    suspend fun setActiveSelection(providerId: String, model: String?) {
        context.settingsStore.edit { prefs ->
            prefs[Keys.ACTIVE_PROVIDER] = providerId
            if (model.isNullOrBlank()) prefs.remove(Keys.ACTIVE_MODEL) else prefs[Keys.ACTIVE_MODEL] = model
        }
    }

    suspend fun setModelSelectionScope(shared: Boolean, selection: ChatModelSelection? = null) {
        context.settingsStore.edit { prefs ->
            if (selection != null) {
                listOf(Keys.ACTIVE_PROVIDER to selection.active?.providerId, Keys.ACTIVE_MODEL to selection.active?.model,
                    Keys.PLANNING_PROVIDER to selection.planning?.providerId, Keys.PLANNING_MODEL to selection.planning?.model,
                    Keys.EXECUTION_PROVIDER to selection.execution?.providerId, Keys.EXECUTION_MODEL to selection.execution?.model
                ).forEach { (key, value) -> if (value == null) prefs.remove(key) else prefs[key] = value }
                prefs[Keys.THINKING_LEVEL] = selection.thinking.name
                prefs[Keys.CUSTOM_THINKING_LEVELS] = kotlinx.serialization.json.Json.encodeToString(selection.customThinkingLevels)
            }
            prefs[Keys.SAME_MODEL_ACROSS_CHATS] = shared
        }
    }

    /** A background switch must not overwrite a newer choice made in the model picker. */
    suspend fun switchActiveSelection(from: com.androidharness.app.llm.ProviderConfig, to: com.androidharness.app.llm.ProviderConfig) {
        context.settingsStore.edit { prefs ->
            if ((prefs[Keys.SAME_MODEL_ACROSS_CHATS] ?: true) && prefs[Keys.ACTIVE_PROVIDER] == from.id && (prefs[Keys.ACTIVE_MODEL] == null || prefs[Keys.ACTIVE_MODEL] == from.model)) {
                prefs[Keys.ACTIVE_PROVIDER] = to.id
                prefs[Keys.ACTIVE_MODEL] = to.model
            }
        }
    }

    suspend fun clearMissingLocalProviderSelections(availableIds: Set<String>) {
        context.settingsStore.edit { prefs ->
            listOf(Keys.ACTIVE_PROVIDER to Keys.ACTIVE_MODEL,
                Keys.PLANNING_PROVIDER to Keys.PLANNING_MODEL,
                Keys.EXECUTION_PROVIDER to Keys.EXECUTION_MODEL,
                Keys.SUBAGENT_PROVIDER to Keys.SUBAGENT_MODEL,
                Keys.ASSISTANT_PROVIDER to Keys.ASSISTANT_MODEL).forEach { (providerKey, modelKey) ->
                val id = prefs[providerKey]
                if (id != null && (com.androidharness.app.local.LocalModelCatalog.isLocal(id) || com.androidharness.app.chatgpt.ChatGptProtocol.isProvider(id)) && id !in availableIds) {
                    if (providerKey == Keys.ACTIVE_PROVIDER) {
                        prefs[providerKey] = com.androidharness.app.llm.HarnessProvider.ID
                    } else prefs.remove(providerKey)
                    prefs.remove(modelKey)
                }
            }
        }
    }

    suspend fun setThinkingLevel(level: ThinkingLevel) {
        context.settingsStore.edit { it[Keys.THINKING_LEVEL] = level.name }
    }

    suspend fun setMaxContextTokens(tokens: Int) {
        context.settingsStore.edit { it[Keys.MAX_CONTEXT] = tokens }
    }

    suspend fun setAutoCompactTokens(tokens: Int) {
        require(tokens == 0 || tokens >= 1_024)
        context.settingsStore.edit { it[Keys.AUTO_COMPACT] = tokens }
    }

    suspend fun setResumePrompt(prompt: String) {
        val clean = prompt.trim()
        require(clean.length <= com.androidharness.app.agent.RunRecovery.MAX_PROMPT_CHARS)
        context.settingsStore.edit { if (clean.isEmpty()) it.remove(Keys.RESUME_PROMPT) else it[Keys.RESUME_PROMPT] = clean }
    }

    suspend fun setMaxOutputTokens(tokens: Int) {
        context.settingsStore.edit { it[Keys.MAX_OUTPUT] = tokens }
    }

    suspend fun setMaxIterations(iterations: Int) {
        context.settingsStore.edit { it[Keys.MAX_ITERATIONS] = iterations }
    }

    suspend fun setRunInBackground(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.RUN_IN_BACKGROUND] = enabled }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setKeepAlive(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.KEEP_ALIVE] = enabled }
    }

    suspend fun setLiveUpdatesEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.LIVE_UPDATES_ENABLED] = enabled }
    }

    suspend fun setPinned(sessionId: String, pinned: Boolean) {
        context.settingsStore.edit { prefs ->
            val current = prefs[Keys.PINNED] ?: emptySet()
            prefs[Keys.PINNED] = if (pinned) current + sessionId else current - sessionId
        }
    }

    suspend fun setSidebarProjects(projects: Boolean) {
        context.settingsStore.edit { it[Keys.SIDEBAR_PROJECTS] = projects }
    }

    suspend fun setProjectPinned(projectId: String, pinned: Boolean) {
        context.settingsStore.edit { prefs ->
            val current = prefs[Keys.PINNED_PROJECTS] ?: emptySet()
            prefs[Keys.PINNED_PROJECTS] = if (pinned) current + projectId else current - projectId
        }
    }

    suspend fun setProjectArchived(projectId: String, archived: Boolean) {
        context.settingsStore.edit { prefs ->
            val current = prefs[Keys.ARCHIVED_PROJECTS] ?: emptySet()
            prefs[Keys.ARCHIVED_PROJECTS] = if (archived) current + projectId else current - projectId
        }
    }

    suspend fun removeProjectReferences(projectId: String, chatIds: Set<String>) {
        context.settingsStore.edit { prefs ->
            prefs[Keys.PINNED_PROJECTS] = (prefs[Keys.PINNED_PROJECTS] ?: emptySet()) - projectId
            prefs[Keys.ARCHIVED_PROJECTS] = (prefs[Keys.ARCHIVED_PROJECTS] ?: emptySet()) - projectId
            prefs[Keys.PINNED] = (prefs[Keys.PINNED] ?: emptySet()) - chatIds
            prefs[Keys.ARCHIVED] = (prefs[Keys.ARCHIVED] ?: emptySet()) - chatIds
            if (prefs[Keys.LAST_ACTIVE_SESSION] in chatIds) prefs.remove(Keys.LAST_ACTIVE_SESSION)
        }
    }

    suspend fun setArchived(sessionId: String, archived: Boolean) = setArchived(setOf(sessionId), archived)

    suspend fun setArchived(sessionIds: Set<String>, archived: Boolean) {
        context.settingsStore.edit { prefs ->
            val current = prefs[Keys.ARCHIVED] ?: emptySet()
            prefs[Keys.ARCHIVED] = if (archived) current + sessionIds else current - sessionIds
        }
    }

    suspend fun restoreArchived(sessionIds: Set<String>, previouslyArchived: Set<String>) {
        context.settingsStore.edit { prefs ->
            prefs[Keys.ARCHIVED] = ((prefs[Keys.ARCHIVED] ?: emptySet()) - sessionIds) + (previouslyArchived intersect sessionIds)
        }
    }

    suspend fun forgetSidebarSessions(sessionIds: Set<String>) {
        context.settingsStore.edit { prefs ->
            prefs[Keys.PINNED] = (prefs[Keys.PINNED] ?: emptySet()) - sessionIds
            prefs[Keys.ARCHIVED] = (prefs[Keys.ARCHIVED] ?: emptySet()) - sessionIds
            if (prefs[Keys.LAST_ACTIVE_SESSION] in sessionIds) prefs.remove(Keys.LAST_ACTIVE_SESSION)
        }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.settingsStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setRepoMapEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.REPO_MAP_ENABLED] = enabled }
    }

    suspend fun setShowLiveCode(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.SHOW_LIVE_CODE] = enabled }
    }

    suspend fun setCavemanInstalled(installed: Boolean) {
        context.settingsStore.edit {
            it[Keys.CAVEMAN_INSTALLED] = installed
            it[Keys.CAVEMAN_INTENSITY] = com.androidharness.app.caveman.CavemanIntensity.OFF.name
        }
    }

    suspend fun setLocalModelAgentContext(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.LOCAL_MODEL_AGENT_CONTEXT] = enabled }
    }

    suspend fun setLocalModelExperimental(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.LOCAL_MODEL_EXPERIMENTAL] = enabled }
    }

    suspend fun setCavemanIntensity(intensity: com.androidharness.app.caveman.CavemanIntensity) {
        context.settingsStore.edit {
            if (it[Keys.CAVEMAN_INSTALLED] == true) it[Keys.CAVEMAN_INTENSITY] = intensity.name
        }
    }

    suspend fun setCavemanWenyan(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.CAVEMAN_WENYAN] = enabled }
    }

    suspend fun setSkillEnabled(name: String, enabled: Boolean) {
        context.settingsStore.edit { prefs ->
            val current = prefs[Keys.DISABLED_SKILLS] ?: emptySet()
            prefs[Keys.DISABLED_SKILLS] = if (enabled) current - name else current + name
        }
    }

    /** Turns many skills on or off in one write, so a bulk change is applied all at once. */
    suspend fun setSkillsEnabled(names: Collection<String>, enabled: Boolean) {
        if (names.isEmpty()) return
        context.settingsStore.edit { prefs ->
            val current = prefs[Keys.DISABLED_SKILLS] ?: emptySet()
            prefs[Keys.DISABLED_SKILLS] = if (enabled) current - names.toSet() else current + names
        }
    }

    /** Model override for the ACTIVE provider; null falls back to its saved default. */
    suspend fun setActiveModel(model: String?) {
        context.settingsStore.edit { prefs ->
            if (model.isNullOrBlank()) prefs.remove(Keys.ACTIVE_MODEL)
            else prefs[Keys.ACTIVE_MODEL] = model
        }
    }

    suspend fun setStartScreen(value: StartScreen) {
        context.settingsStore.edit { it[Keys.START_SCREEN] = value.name }
    }

    suspend fun setChatKeepThinkingCollapsed(value: Boolean) {
        context.settingsStore.edit { it[Keys.CHAT_KEEP_THINKING_COLLAPSED] = value }
    }

    suspend fun setChatRemindersEnabled(value: Boolean) {
        context.settingsStore.edit { it[Keys.CHAT_REMINDERS_ENABLED] = value }
    }

    suspend fun setReadImageText(value: Boolean) {
        context.settingsStore.edit { it[Keys.READ_IMAGE_TEXT] = value }
    }

    suspend fun setRumbleEnabled(value: Boolean) {
        context.settingsStore.edit { it[Keys.RUMBLE_ENABLED] = value }
    }

    suspend fun setRumbleStrength(value: Int) {
        context.settingsStore.edit { it[Keys.RUMBLE_STRENGTH] = value.coerceIn(0, 100) }
    }

    suspend fun setRumbleSmoothness(value: Int) {
        context.settingsStore.edit { it[Keys.RUMBLE_SMOOTHNESS] = value.coerceIn(0, 100) }
    }

    suspend fun setRumbleEngine(value: RumbleEngine) {
        context.settingsStore.edit { it[Keys.RUMBLE_ENGINE] = value.name }
    }

    suspend fun setRumbleInChat(value: Boolean) {
        context.settingsStore.edit { it[Keys.RUMBLE_IN_CHAT] = value }
    }

    suspend fun setRumbleInCode(value: Boolean) {
        context.settingsStore.edit { it[Keys.RUMBLE_IN_CODE] = value }
    }

    suspend fun setRumbleFlow(value: Boolean) {
        context.settingsStore.edit { it[Keys.RUMBLE_FLOW] = value }
    }

    suspend fun setRumbleSpacing(value: Int) {
        context.settingsStore.edit { it[Keys.RUMBLE_SPACING] = value.coerceIn(RUMBLE_MIN_SPACING_MS, RUMBLE_MAX_SPACING_MS) }
    }

    suspend fun setRumbleSkipOnBatterySaver(value: Boolean) {
        context.settingsStore.edit { it[Keys.RUMBLE_BATTERY_SAVER] = value }
    }

    /** Saving a cue that matches its default drops the override. */
    suspend fun setRumbleCue(cue: RumbleCue, config: RumbleCueConfig) {
        context.settingsStore.edit { prefs ->
            val saved = decodeRumbleCues(prefs[Keys.RUMBLE_CUES]).toMutableMap()
            val combo = (prefs[Keys.RUMBLE_COMBO] ?: RUMBLE_DEFAULT_COMBO).coerceIn(0, RUMBLE_COMBO_COUNT - 1)
            if (config == rumbleComboConfig(combo, cue)) saved.remove(cue.name) else saved[cue.name] = config
            prefs[Keys.RUMBLE_CUES] = encodeRumbleCues(saved)
        }
    }

    suspend fun resetRumble() {
        context.settingsStore.edit { prefs ->
            listOf(Keys.RUMBLE_ENABLED, Keys.RUMBLE_STRENGTH, Keys.RUMBLE_SMOOTHNESS, Keys.RUMBLE_IN_CHAT, Keys.RUMBLE_IN_CODE, Keys.RUMBLE_FLOW,
                Keys.RUMBLE_SPACING, Keys.RUMBLE_BATTERY_SAVER).forEach { prefs.remove(it) }
            prefs.remove(Keys.RUMBLE_ENGINE)
            prefs.remove(Keys.RUMBLE_CUES)
            prefs[Keys.RUMBLE_COMBO] = kotlin.random.Random.nextInt(RUMBLE_COMBO_COUNT)
        }
    }

    /** A fresh install gets a random set of event patterns once, then keeps it. */
    suspend fun ensureRumbleCombo() {
        context.settingsStore.edit { prefs ->
            if (Keys.RUMBLE_COMBO !in prefs) prefs[Keys.RUMBLE_COMBO] = kotlin.random.Random.nextInt(RUMBLE_COMBO_COUNT)
        }
    }

    /** Rolls a different set than the current one and clears the per-event overrides. Returns the new set. */
    suspend fun shuffleRumbleCombo(): Int {
        var next = RUMBLE_DEFAULT_COMBO
        context.settingsStore.edit { prefs ->
            val current = (prefs[Keys.RUMBLE_COMBO] ?: RUMBLE_DEFAULT_COMBO).coerceIn(0, RUMBLE_COMBO_COUNT - 1)
            next = (0 until RUMBLE_COMBO_COUNT).filter { it != current }.random()
            prefs[Keys.RUMBLE_COMBO] = next
            prefs.remove(Keys.RUMBLE_CUES)
        }
        return next
    }

    suspend fun setChatImageFrequency(value: ImageFrequency) {
        context.settingsStore.edit { it[Keys.CHAT_IMAGE_FREQUENCY] = value.name }
    }

    suspend fun setChatInstructions(value: String) {
        context.settingsStore.edit { it[Keys.CHAT_INSTRUCTIONS] = value.trim().take(ConversationConfig.MAX_INSTRUCTIONS_CHARS) }
    }

    suspend fun saveChatAgent(profile: ChatAgentProfile) {
        profile.validated()
        context.settingsStore.edit { prefs ->
            val current = ChatAgentProfile.decodeList(prefs[Keys.CHAT_AGENTS])
            prefs[Keys.CHAT_AGENTS] = ChatAgentProfile.encodeList(current.filterNot { it.id == profile.id } + profile.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun deleteChatAgent(id: String) {
        context.settingsStore.edit { prefs ->
            prefs[Keys.CHAT_AGENTS] = ChatAgentProfile.encodeList(ChatAgentProfile.decodeList(prefs[Keys.CHAT_AGENTS]).filterNot { it.id == id })
        }
    }

    suspend fun setChatSearchCodeChats(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.CHAT_SEARCH_CODE_CHATS] = enabled }
    }

    suspend fun setCodeSearchChatChats(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.CODE_SEARCH_CHAT_CHATS] = enabled }
    }

    suspend fun setChatStart(value: ChatStartMode) {
        context.settingsStore.edit { it[Keys.CHAT_START] = value.name }
    }

    suspend fun setCodeStart(value: CodeStartMode) {
        context.settingsStore.edit {
            it[Keys.CODE_START] = value.name
            it[Keys.RESUME_LAST_CHAT] = value == CodeStartMode.LAST_CODE
        }
    }

    suspend fun setSectionMemoryEnabled(section: MemorySection, enabled: Boolean) {
        context.settingsStore.edit { it[if (section == MemorySection.CHAT) Keys.CHAT_MEMORY_ENABLED else Keys.CODE_MEMORY_ENABLED] = enabled }
    }

    suspend fun setCrossSectionMemory(section: MemorySection, enabled: Boolean) {
        context.settingsStore.edit { it[if (section == MemorySection.CHAT) Keys.CHAT_RECALL_CODE_MEMORY else Keys.CODE_RECALL_CHAT_MEMORY] = enabled }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.MEMORY_ENABLED] = enabled }
    }

    suspend fun setMemoryEntryUnlimited(unlimited: Boolean) {
        context.settingsStore.edit { it[Keys.MEMORY_ENTRY_UNLIMITED] = unlimited }
    }

    suspend fun setMemoryEntryMaxChars(maxChars: Int) {
        require(maxChars > 0) { "Enter a positive whole number." }
        context.settingsStore.edit { it[Keys.MEMORY_ENTRY_MAX_CHARS] = maxChars }
    }

    suspend fun setSearchDepth(depth: SearchDepth) {
        context.settingsStore.edit { it[Keys.SEARCH_DEPTH] = depth.name }
    }

    suspend fun setSteeringMode(mode: SteeringMode) {
        context.settingsStore.edit { it[Keys.STEERING_MODE] = mode.name }
    }

    suspend fun setRunTipsEnabled(enabled: Boolean) {
        context.settingsStore.edit { it[Keys.RUN_TIPS_ENABLED] = enabled }
    }

    suspend fun setAgentSettingsAccess(access: AgentSettingsAccess) {
        context.settingsStore.edit { it[Keys.AGENT_SETTINGS_ACCESS] = access.name }
    }

    suspend fun setRunTipCursor(cursor: Int) {
        context.settingsStore.edit { it[Keys.RUN_TIP_CURSOR] = cursor }
    }

    suspend fun setLastConversationKind(value: ConversationKind) {
        context.settingsStore.edit { it[Keys.LAST_CONVERSATION_KIND] = value.name }
    }

    suspend fun setResumeLastChat(enabled: Boolean) {
        context.settingsStore.edit {
            it[Keys.RESUME_LAST_CHAT] = enabled
            it[Keys.CODE_START] = (if (enabled) CodeStartMode.LAST_CODE else CodeStartMode.NEW_CODE).name
        }
    }

    suspend fun setLastActiveSessionId(sessionId: String?) {
        context.settingsStore.edit { prefs ->
            if (sessionId.isNullOrBlank()) prefs.remove(Keys.LAST_ACTIVE_SESSION)
            else prefs[Keys.LAST_ACTIVE_SESSION] = sessionId
        }
    }
}

/** Entries are "providerId|model=tokens"; the key itself may hold "=", so split on the last one. */
internal fun decodeContextLimits(entries: Set<String>?): Map<String, Int> =
    entries.orEmpty().mapNotNull { entry ->
        val at = entry.lastIndexOf('=')
        if (at <= 0) return@mapNotNull null
        entry.substring(at + 1).toIntOrNull()?.takeIf { it > 0 }?.let { entry.substring(0, at) to it }
    }.toMap()

internal fun encodeContextLimits(limits: Map<String, Int>): Set<String> =
    limits.mapTo(LinkedHashSet()) { (key, tokens) -> "$key=$tokens" }
